# Kafka-Avro-scala

Assumptions:
Following are installed and configured properly
a. Java 1.8 
b. Scala 2.12.x
c. SBT 1.0.4


1. cd kas

2. sbt

After getting into the sbt shell,

3. sbt:kafka-avro> reload

4. sbt:kafka-avro> compile

5. sbt:kafka-avro> run

Now options will be displayed, from which select the object to be executed

Multiple main classes detected, select one to run:

 [1] com.example.streams.Kaf2MaprFSClient
 [2] demoApp.ConsumerApp
 [3] demoApp.KMConsumerApp
 [4] demoApp.ProducerApp
[warn] Multiple main classes detected.  Run 'show discoveredMainClasses' to see the list

Select firstly, demoApp.ProducerApp by pressing 4, and once it is done, then

com.example.streams.Kaf2MaprFSClient by pressing 1.

Check the result at the MapR FS using the following command,

hadoop fs -ls /user/mapr/

There you will find a file named avrodata.avro is created.
