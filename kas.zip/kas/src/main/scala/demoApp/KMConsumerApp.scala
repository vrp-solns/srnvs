package demoApp

import java.io._
import java.util.Arrays
import consumer.KafkaConsumer

object KMConsumerApp extends App {

  val consumer = new KafkaConsumer()
  val avroFileName = "avrodata.avro"
  while (true) {
  try{
    consumer.read() match {
      case Some(message) =>
        println("Got message: " + message)
        println("Creating new file")
                val testfile = new File(avroFileName)
                val testfileWriter = new BufferedWriter(new FileWriter(testfile))
                println("Writing avro data into the " + avroFileName)
                //testfileWriter.write(message)
                testfileWriter.close
                println("Saving the file " + avroFileName + " to MaprFs")
                MapRfsFileService.createAndSave(avroFileName)
        Thread.sleep(100)
      case _ =>
        println("Queue is empty.......................  ")
        // wait for 2 second
        Thread.sleep(2 * 1000)
    }
    } catch {
            case ex: Exception => ex.printStackTrace()
            None
        }
    //Close the FileSystem Handle
     MapRfsFileService.close
  }

}