package demoApp

import domain.User
import producer. KafkaProducer

object ProducerApp extends App {

  private val topic = "demo-topic"

  val producer = new KafkaProducer()

  val user1 = User(1, "User1", None)
  val user2 = User(2, "User2", Some("user2@mail.com"))
  val user3 = User(3, "User3", Some("user3@mail.com"))
  val user4 = User(4, "User4", None)
  val user5 = User(5, "User5", Some("user5@mail.com"))
  val user6 = User(6, "User6", Some("user6@mail.com"))
  val user7 = User(7, "User7", Some("user7@mail.com"))
  val user8 = User(8, "User8", None)
  val user9 = User(9, "User9", Some("user9@mail.com"))

  producer.send(topic, List(user1, user2, user3, user4, user5, user6, user7, user8, user9))

}