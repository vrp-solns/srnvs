package com.example.streams
import java.io._
import java.util.Arrays
import consumer.KafkaConsumer
import com.example.MapRfsFileService

object Kaf2MaprFSClient {//extends App {
  def main(args: Array[String]) {
    val avroFileName = "avrodata.avro"
       
    val consumer = new KafkaConsumer()
    //val MapRfsFileService = new MapRfsFileService()
    var localCount:Int=1;
    var avroMsg:String="";
    while (true) {
        try{
          println("############ in while loop")
          consumer.read() match {
            
            case Some(message) =>
              println("Got message: " + message)
              avroMsg+=message;
              localCount+=1;
              if (localCount%5==0){
                //Creating a new file and saving it to MapRFS
      
                println("Creating new file")
                val testfile = new File(avroFileName)
                val testfileWriter = new BufferedWriter(new FileWriter(testfile))
                println("Writing avro data into the " + avroFileName)
                testfileWriter.write(avroMsg)
                testfileWriter.close
                println("Saving the file " + avroFileName + " to MaprFs")
                MapRfsFileService.createAndSave(avroFileName)
              }
              Thread.sleep(100)
            case _ =>
              println("Queue is empty.......................  ")
              // wait for 2 second
              Thread.sleep(1000)
          }
        } catch {
            case ex: Exception => ex.printStackTrace()
            None
        }
    }    
   //Close the FileSystem Handle
     MapRfsFileService.close
   }
 }